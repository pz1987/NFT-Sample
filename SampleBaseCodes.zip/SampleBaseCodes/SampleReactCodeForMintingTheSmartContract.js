import React, { useState, useEffect } from "react";
import { Button, Form, Image } from "react-bootstrap";
import Web3 from "web3";
import MyNFTContract from "./contracts/MyNFT.json";

function App() {
  const [web3, setWeb3] = useState(null);
  const [account, setAccount] = useState("");
  const [contract, setContract] = useState(null);
  const [tokenId, setTokenId] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [imageURI, setImageURI] = useState("");

  useEffect(() => {
    const init = async () => {
      if (typeof window.ethereum !== "undefined") {
        const _web3 = new Web3(window.ethereum);
        const _accounts = await _web3.eth.requestAccounts();
        setWeb3(_web3);
        setAccount(_accounts[0]);
        const _contract = new _web3.eth.Contract(
          MyNFTContract.abi,
          MyNFTContract.networks[4].address
        );
        setContract(_contract);
      }
    };
    init();
  }, []);

  const handleMintNFT = async (event) => {
    event.preventDefault();
    const name = prompt("Enter NFT name:");
    const description = prompt("Enter NFT description:");
    const imageURI = prompt("Enter NFT image URI:");
    try {
      await contract.methods.mintNFT(imageURI).send({ from: account });
      const latestTokenId = await contract.methods.tokenByIndex(4).call();
      setTokenId(latestTokenId);
      setName(name);
      setDescription(description);
      setImageURI(imageURI);
    } catch (error) {
      console.error(error);
      alert("Error minting NFT. Please try again later.");
    }
  };

  return (
    <div className="App">
      <h1>My NFT App</h1>
      <p>Connected Account: {account}</p>
      {tokenId !== "" && (
        <>
          <h2>{name}</h2>
          <p>{description}</p>
          <Image src={imageURI} />
          <p>Token ID: {tokenId}</p>
        </>
      )}
      <Form onSubmit={handleMintNFT}>
        <Button type="submit" variant="primary">
          Mint NFT
        </Button>
      </Form>
    </div>
  );
